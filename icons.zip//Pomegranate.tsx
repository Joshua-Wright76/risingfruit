export function Pomegranate() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="16" fill="#DC143C" stroke="#8B0000" strokeWidth="2"/>
      <path d="M 26 18 Q 32 14 38 18" stroke="#6B8E23" strokeWidth="2" fill="none"/>
      <line x1="32" y1="18" x2="32" y2="14" stroke="#6B8E23" strokeWidth="2"/>
      <circle cx="28" cy="30" r="2" fill="#FFB6C1"/>
      <circle cx="36" cy="30" r="2" fill="#FFB6C1"/>
      <circle cx="32" cy="36" r="2" fill="#FFB6C1"/>
      <circle cx="26" cy="38" r="2" fill="#FFB6C1"/>
      <circle cx="38" cy="38" r="2" fill="#FFB6C1"/>
      <circle cx="32" cy="42" r="2" fill="#FFB6C1"/>
    </svg>
  );
}
