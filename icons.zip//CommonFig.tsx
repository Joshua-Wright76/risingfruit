export function CommonFig() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 32 20 Q 22 24 20 34 Q 20 44 28 48 Q 32 50 36 48 Q 44 44 44 34 Q 42 24 32 20 Z" fill="#8B6F47" stroke="#654321" strokeWidth="2"/>
      <circle cx="32" cy="22" r="3" fill="#556B2F"/>
      <path d="M 28 24 L 30 20 L 34 20 L 36 24" stroke="#556B2F" strokeWidth="1.5" fill="none"/>
      <circle cx="30" cy="36" r="2" fill="#D2691E" opacity="0.6"/>
      <circle cx="34" cy="38" r="2" fill="#D2691E" opacity="0.6"/>
      <circle cx="32" cy="42" r="2" fill="#D2691E" opacity="0.6"/>
    </svg>
  );
}
