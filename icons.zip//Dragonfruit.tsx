export function Dragonfruit() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="32" cy="36" rx="13" ry="15" fill="#FF69B4" stroke="#C71585" strokeWidth="2"/>
      <path d="M 26 20 L 28 16 L 30 20" stroke="#7CB342" strokeWidth="2" fill="none"/>
      <path d="M 32 18 L 34 14 L 36 18" stroke="#7CB342" strokeWidth="2" fill="none"/>
      <path d="M 38 20 L 40 16 L 42 20" stroke="#7CB342" strokeWidth="2" fill="none"/>
      <circle cx="28" cy="32" r="1.5" fill="#2F4F4F"/>
      <circle cx="34" cy="30" r="1.5" fill="#2F4F4F"/>
      <circle cx="36" cy="34" r="1.5" fill="#2F4F4F"/>
      <circle cx="30" cy="38" r="1.5" fill="#2F4F4F"/>
      <circle cx="36" cy="40" r="1.5" fill="#2F4F4F"/>
      <circle cx="32" cy="44" r="1.5" fill="#2F4F4F"/>
      <circle cx="26" cy="42" r="1.5" fill="#2F4F4F"/>
    </svg>
  );
}
