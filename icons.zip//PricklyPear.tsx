export function PricklyPear() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="32" cy="36" rx="10" ry="14" fill="#9ACD32" stroke="#6B8E23" strokeWidth="2"/>
      <line x1="26" y1="26" x2="24" y2="22" stroke="#8B4513" strokeWidth="1.5"/>
      <line x1="32" y1="24" x2="32" y2="20" stroke="#8B4513" strokeWidth="1.5"/>
      <line x1="38" y1="26" x2="40" y2="22" stroke="#8B4513" strokeWidth="1.5"/>
      <line x1="24" y1="36" x2="20" y2="36" stroke="#8B4513" strokeWidth="1.5"/>
      <line x1="40" y1="36" x2="44" y2="36" stroke="#8B4513" strokeWidth="1.5"/>
      <line x1="26" y1="46" x2="24" y2="50" stroke="#8B4513" strokeWidth="1.5"/>
      <line x1="38" y1="46" x2="40" y2="50" stroke="#8B4513" strokeWidth="1.5"/>
      <circle cx="28" cy="32" r="1.5" fill="#FFD700"/>
      <circle cx="36" cy="34" r="1.5" fill="#FFD700"/>
      <circle cx="32" cy="40" r="1.5" fill="#FFD700"/>
    </svg>
  );
}
