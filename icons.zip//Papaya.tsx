export function Papaya() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="32" cy="34" rx="12" ry="16" fill="#FF8C00" stroke="#FF6347" strokeWidth="2"/>
      <path d="M 32 18 Q 34 14 36 12" stroke="#228B22" strokeWidth="2" fill="none"/>
      <ellipse cx="36" cy="12" rx="5" ry="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <ellipse cx="32" cy="34" rx="6" ry="10" fill="#FFB347" opacity="0.7"/>
      <circle cx="30" cy="30" r="2" fill="#2F4F4F" opacity="0.8"/>
      <circle cx="34" cy="32" r="2" fill="#2F4F4F" opacity="0.8"/>
      <circle cx="30" cy="36" r="2" fill="#2F4F4F" opacity="0.8"/>
      <circle cx="34" cy="38" r="2" fill="#2F4F4F" opacity="0.8"/>
      <circle cx="32" cy="42" r="2" fill="#2F4F4F" opacity="0.8"/>
    </svg>
  );
}
