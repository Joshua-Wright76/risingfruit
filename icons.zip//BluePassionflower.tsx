export function BluePassionflower() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="18" fill="#E6E6FA" stroke="#4169E1" strokeWidth="2"/>
      <circle cx="32" cy="32" r="12" fill="#9370DB" opacity="0.4"/>
      <circle cx="32" cy="32" r="6" fill="#4169E1"/>
      {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => {
        const rad = (angle * Math.PI) / 180;
        const x1 = 32 + Math.cos(rad) * 6;
        const y1 = 32 + Math.sin(rad) * 6;
        const x2 = 32 + Math.cos(rad) * 18;
        const y2 = 32 + Math.sin(rad) * 18;
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#4169E1" strokeWidth="2" />;
      })}
      <circle cx="32" cy="32" r="3" fill="#FFD700" stroke="#FFA500" strokeWidth="1"/>
    </svg>
  );
}
