export function Olive() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="32" cy="34" rx="8" ry="12" fill="#6B8E23" stroke="#556B2F" strokeWidth="2"/>
      <path d="M 32 22 L 30 18 L 28 16" stroke="#8B7355" strokeWidth="2" fill="none"/>
      <ellipse cx="26" cy="16" rx="6" ry="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <ellipse cx="36" cy="18" rx="5" ry="2" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <ellipse cx="32" cy="34" rx="3" ry="5" fill="#8FBC8F" opacity="0.5"/>
    </svg>
  );
}
