export function Rose() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="30" r="10" fill="#FFB6C1" stroke="#C71585" strokeWidth="2"/>
      <circle cx="32" cy="30" r="6" fill="#FF69B4" stroke="#C71585" strokeWidth="1.5"/>
      <circle cx="32" cy="30" r="3" fill="#DC143C"/>
      <line x1="32" y1="40" x2="32" y2="52" stroke="#228B22" strokeWidth="2"/>
      <path d="M 32 44 Q 26 46 24 48" stroke="#228B22" strokeWidth="1.5" fill="none"/>
      <ellipse cx="24" cy="48" rx="5" ry="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <path d="M 32 46 Q 38 48 40 50" stroke="#228B22" strokeWidth="1.5" fill="none"/>
      <ellipse cx="40" cy="50" rx="5" ry="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
    </svg>
  );
}
