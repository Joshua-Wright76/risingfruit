export function StrawberryHedgehog() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="35" r="16" fill="#8FBC8F" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="32" y1="19" x2="32" y2="13" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="32" y1="51" x2="32" y2="57" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="16" y1="35" x2="10" y2="35" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="48" y1="35" x2="54" y2="35" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="21" y1="24" x2="16" y2="19" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="43" y1="24" x2="48" y2="19" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="21" y1="46" x2="16" y2="51" stroke="#2F4F2F" strokeWidth="2"/>
      <line x1="43" y1="46" x2="48" y2="51" stroke="#2F4F2F" strokeWidth="2"/>
      <circle cx="32" cy="32" r="3" fill="#FF69B4"/>
      <circle cx="26" cy="38" r="2" fill="#FF69B4"/>
      <circle cx="38" cy="38" r="2" fill="#FF69B4"/>
    </svg>
  );
}
