export function CollardGreens() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 32 48 Q 24 42 22 32 Q 22 22 28 16 Q 32 20 32 28 Z" fill="#2E7D32" stroke="#1B5E20" strokeWidth="2"/>
      <path d="M 32 48 Q 40 42 42 32 Q 42 22 36 16 Q 32 20 32 28 Z" fill="#388E3C" stroke="#1B5E20" strokeWidth="2"/>
      <line x1="32" y1="28" x2="28" y2="24" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="32" x2="28" y2="30" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="36" x2="28" y2="34" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="28" x2="36" y2="24" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="32" x2="36" y2="30" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="36" x2="36" y2="34" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
    </svg>
  );
}
