export function Sapote() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="36" r="14" fill="#8B4513" stroke="#654321" strokeWidth="2"/>
      <path d="M 32 22 Q 34 18 38 18" stroke="#228B22" strokeWidth="2" fill="none"/>
      <ellipse cx="38" cy="18" rx="6" ry="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <ellipse cx="32" cy="36" rx="8" ry="10" fill="#CD853F" opacity="0.6"/>
      <circle cx="32" cy="38" r="4" fill="#4B3621"/>
    </svg>
  );
}
