export function Sage() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="32" y1="48" x2="32" y2="16" stroke="#6B8E23" strokeWidth="2"/>
      <ellipse cx="28" cy="22" rx="8" ry="5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <ellipse cx="36" cy="26" rx="7" ry="4.5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <ellipse cx="28" cy="32" rx="8" ry="5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <ellipse cx="36" cy="36" rx="7" ry="4.5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <ellipse cx="28" cy="42" rx="7" ry="4" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
    </svg>
  );
}
