export function Chayote() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 32 20 Q 24 22 20 30 Q 18 38 24 46 Q 32 50 40 46 Q 46 38 44 30 Q 40 22 32 20 Z" fill="#9ACD32" stroke="#6B8E23" strokeWidth="2"/>
      <path d="M 32 20 Q 34 16 38 16" stroke="#228B22" strokeWidth="2" fill="none"/>
      <path d="M 38 16 Q 40 16 42 18 Q 42 20 40 22" stroke="#228B22" strokeWidth="1.5" fill="none"/>
      <line x1="26" y1="28" x2="26" y2="44" stroke="#7CB342" strokeWidth="1" opacity="0.5"/>
      <line x1="30" y1="26" x2="30" y2="46" stroke="#7CB342" strokeWidth="1" opacity="0.5"/>
      <line x1="34" y1="26" x2="34" y2="46" stroke="#7CB342" strokeWidth="1" opacity="0.5"/>
      <line x1="38" y1="28" x2="38" y2="44" stroke="#7CB342" strokeWidth="1" opacity="0.5"/>
    </svg>
  );
}
