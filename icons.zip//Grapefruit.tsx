export function Grapefruit() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="16" fill="#FF6347" stroke="#FF4500" strokeWidth="2"/>
      <rect x="30" y="16" width="4" height="6" fill="#228B22" rx="1"/>
      <ellipse cx="32" cy="16" rx="4" ry="2" fill="#7CB342"/>
      <circle cx="32" cy="34" r="2.5" fill="#FFE4B5" opacity="0.8"/>
      <line x1="32" y1="34" x2="32" y2="20" stroke="#FFE4B5" strokeWidth="1.5" opacity="0.5"/>
      <line x1="32" y1="34" x2="46" y2="34" stroke="#FFE4B5" strokeWidth="1.5" opacity="0.5"/>
      <line x1="32" y1="34" x2="21" y2="45" stroke="#FFE4B5" strokeWidth="1.5" opacity="0.5"/>
      <line x1="32" y1="34" x2="43" y2="45" stroke="#FFE4B5" strokeWidth="1.5" opacity="0.5"/>
      <line x1="32" y1="34" x2="21" y2="23" stroke="#FFE4B5" strokeWidth="1.5" opacity="0.5"/>
      <line x1="32" y1="34" x2="43" y2="23" stroke="#FFE4B5" strokeWidth="1.5" opacity="0.5"/>
    </svg>
  );
}
