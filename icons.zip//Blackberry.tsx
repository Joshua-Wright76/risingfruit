export function Blackberry() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="32" cy="36" rx="10" ry="13" fill="#2F4F4F" stroke="#191970" strokeWidth="2"/>
      <circle cx="28" cy="30" r="3" fill="#4B0082" stroke="#191970" strokeWidth="1"/>
      <circle cx="36" cy="30" r="3" fill="#4B0082" stroke="#191970" strokeWidth="1"/>
      <circle cx="32" cy="34" r="3" fill="#4B0082" stroke="#191970" strokeWidth="1"/>
      <circle cx="28" cy="38" r="3" fill="#4B0082" stroke="#191970" strokeWidth="1"/>
      <circle cx="36" cy="38" r="3" fill="#4B0082" stroke="#191970" strokeWidth="1"/>
      <circle cx="32" cy="42" r="3" fill="#4B0082" stroke="#191970" strokeWidth="1"/>
      <path d="M 32 23 Q 34 20 36 18" stroke="#228B22" strokeWidth="2" fill="none"/>
      <ellipse cx="36" cy="18" rx="5" ry="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
    </svg>
  );
}
