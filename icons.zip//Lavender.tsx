export function Lavender() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Left stem */}
      <line x1="26" y1="48" x2="26" y2="26" stroke="#6B8E23" strokeWidth="2"/>
      <rect x="24" y="16" width="4" height="10" fill="#9370DB" stroke="#8B008B" strokeWidth="1.5" rx="2"/>
      <line x1="24" y1="18" x2="22" y2="16" stroke="#8B008B" strokeWidth="1"/>
      <line x1="28" y1="18" x2="30" y2="16" stroke="#8B008B" strokeWidth="1"/>
      
      {/* Center stem */}
      <line x1="32" y1="48" x2="32" y2="24" stroke="#6B8E23" strokeWidth="2"/>
      <rect x="30" y="14" width="4" height="10" fill="#9370DB" stroke="#8B008B" strokeWidth="1.5" rx="2"/>
      <line x1="30" y1="16" x2="28" y2="14" stroke="#8B008B" strokeWidth="1"/>
      <line x1="34" y1="16" x2="36" y2="14" stroke="#8B008B" strokeWidth="1"/>
      
      {/* Right stem */}
      <line x1="38" y1="48" x2="38" y2="26" stroke="#6B8E23" strokeWidth="2"/>
      <rect x="36" y="16" width="4" height="10" fill="#9370DB" stroke="#8B008B" strokeWidth="1.5" rx="2"/>
      <line x1="36" y1="18" x2="34" y2="16" stroke="#8B008B" strokeWidth="1"/>
      <line x1="40" y1="18" x2="42" y2="16" stroke="#8B008B" strokeWidth="1"/>
    </svg>
  );
}
