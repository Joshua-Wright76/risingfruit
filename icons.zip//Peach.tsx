export function Peach() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="30" cy="34" r="14" fill="#FFDAB9" stroke="#FF8C69" strokeWidth="2"/>
      <circle cx="36" cy="32" r="11" fill="#FFB6A3" stroke="#FF8C69" strokeWidth="2"/>
      <path d="M 32 18 Q 28 14 24 14 Q 22 14 22 16 Q 22 18 24 18 Q 26 18 28 16" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <path d="M 28 22 Q 30 18 34 18 Q 36 18 36 20" stroke="#558B2F" strokeWidth="1.5" fill="none"/>
    </svg>
  );
}
