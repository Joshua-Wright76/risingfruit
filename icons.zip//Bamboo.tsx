export function Bamboo() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="28" y="14" width="8" height="14" fill="#90EE90" stroke="#228B22" strokeWidth="2" rx="1"/>
      <rect x="28" y="30" width="8" height="14" fill="#7CFC00" stroke="#228B22" strokeWidth="2" rx="1"/>
      <rect x="28" y="46" width="8" height="6" fill="#90EE90" stroke="#228B22" strokeWidth="2" rx="1"/>
      <line x1="28" y1="28" x2="36" y2="28" stroke="#228B22" strokeWidth="2"/>
      <line x1="28" y1="44" x2="36" y2="44" stroke="#228B22" strokeWidth="2"/>
      <path d="M 36 20 L 42 18 L 44 20" stroke="#228B22" strokeWidth="1.5" fill="none"/>
      <path d="M 36 36 L 42 34 L 44 36" stroke="#228B22" strokeWidth="1.5" fill="none"/>
    </svg>
  );
}
