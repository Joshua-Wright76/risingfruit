export function Thyme() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Left stem */}
      <line x1="26" y1="48" x2="26" y2="16" stroke="#6B8E23" strokeWidth="2"/>
      <ellipse cx="24" cy="20" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="28" cy="22" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="24" cy="26" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="28" cy="30" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="24" cy="34" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="28" cy="38" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="24" cy="42" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      
      {/* Center stem */}
      <line x1="32" y1="48" x2="32" y2="16" stroke="#6B8E23" strokeWidth="2"/>
      <ellipse cx="30" cy="20" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="34" cy="22" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="30" cy="26" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="34" cy="30" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="30" cy="34" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="34" cy="38" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="30" cy="42" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      
      {/* Right stem */}
      <line x1="38" y1="48" x2="38" y2="16" stroke="#6B8E23" strokeWidth="2"/>
      <ellipse cx="36" cy="20" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="40" cy="22" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="36" cy="26" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="40" cy="30" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="36" cy="34" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="40" cy="38" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
      <ellipse cx="36" cy="42" rx="3" ry="2" fill="#8FBC8F" stroke="#556B2F" strokeWidth="1"/>
    </svg>
  );
}