export function Tomato() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="36" r="14" fill="#FF6347" stroke="#DC143C" strokeWidth="2"/>
      <path d="M 26 22 L 28 20 L 30 22 L 32 20 L 34 22 L 36 20 L 38 22" stroke="#228B22" strokeWidth="2" fill="none"/>
      <circle cx="26" cy="22" r="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1"/>
      <circle cx="30" cy="22" r="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1"/>
      <circle cx="34" cy="22" r="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1"/>
      <circle cx="38" cy="22" r="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1"/>
      <ellipse cx="26" cy="32" rx="3" ry="5" fill="#FF7F7F" opacity="0.4"/>
    </svg>
  );
}
