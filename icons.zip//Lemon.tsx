export function Lemon() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="32" cy="34" rx="12" ry="15" fill="#FFFF00" stroke="#FFD700" strokeWidth="2"/>
      <path d="M 32 19 Q 30 16 28 15" stroke="#228B22" strokeWidth="2" fill="none"/>
      <ellipse cx="28" cy="15" rx="5" ry="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <ellipse cx="32" cy="34" rx="6" ry="8" fill="#FFFACD" opacity="0.5"/>
      <line x1="32" y1="26" x2="32" y2="42" stroke="#FFD700" strokeWidth="1" opacity="0.3"/>
    </svg>
  );
}
