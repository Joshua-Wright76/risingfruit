export function Shiso() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 32 46 L 28 40 Q 22 36 20 28 Q 20 22 24 18 L 32 20 Z" fill="#8B4789" stroke="#4B0082" strokeWidth="2"/>
      <path d="M 32 46 L 36 40 Q 42 36 44 28 Q 44 22 40 18 L 32 20 Z" fill="#9370DB" stroke="#4B0082" strokeWidth="2"/>
      <line x1="32" y1="20" x2="28" y2="24" stroke="#DDA0DD" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="26" x2="26" y2="30" stroke="#DDA0DD" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="32" x2="26" y2="36" stroke="#DDA0DD" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="20" x2="36" y2="24" stroke="#DDA0DD" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="26" x2="38" y2="30" stroke="#DDA0DD" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="32" x2="38" y2="36" stroke="#DDA0DD" strokeWidth="1" opacity="0.6"/>
    </svg>
  );
}
