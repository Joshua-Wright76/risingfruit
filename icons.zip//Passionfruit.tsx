export function Passionfruit() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="14" fill="#8B008B" stroke="#4B0082" strokeWidth="2"/>
      <path d="M 32 20 Q 34 16 38 16" stroke="#228B22" strokeWidth="2" fill="none"/>
      <ellipse cx="38" cy="16" rx="5" ry="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <circle cx="28" cy="30" r="1.5" fill="#FFD700"/>
      <circle cx="36" cy="30" r="1.5" fill="#FFD700"/>
      <circle cx="32" cy="34" r="1.5" fill="#FFD700"/>
      <circle cx="28" cy="38" r="1.5" fill="#FFD700"/>
      <circle cx="36" cy="38" r="1.5" fill="#FFD700"/>
      <circle cx="32" cy="42" r="1.5" fill="#FFD700"/>
    </svg>
  );
}
