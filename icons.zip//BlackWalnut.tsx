export function BlackWalnut() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="13" fill="#8B4513" stroke="#654321" strokeWidth="2"/>
      <path d="M 25 27 Q 32 20 39 27" stroke="#654321" strokeWidth="1.5" fill="none"/>
      <path d="M 25 41 Q 32 48 39 41" stroke="#654321" strokeWidth="1.5" fill="none"/>
      <line x1="25" y1="27" x2="25" y2="41" stroke="#654321" strokeWidth="1.5"/>
      <line x1="39" y1="27" x2="39" y2="41" stroke="#654321" strokeWidth="1.5"/>
      <rect x="30" y="18" width="4" height="5" fill="#8B7355" rx="1"/>
    </svg>
  );
}
