export function JapanesePersimmon() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="36" r="14" fill="#FF8C00" stroke="#FF6347" strokeWidth="2"/>
      <path d="M 26 22 L 28 20 L 32 22 L 36 20 L 38 22" stroke="#8B4513" strokeWidth="2" fill="none"/>
      <circle cx="28" cy="22" r="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <circle cx="32" cy="22" r="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <circle cx="36" cy="22" r="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <line x1="32" y1="26" x2="32" y2="48" stroke="#CD853F" strokeWidth="1" opacity="0.3"/>
      <line x1="24" y1="36" x2="40" y2="36" stroke="#CD853F" strokeWidth="1" opacity="0.3"/>
    </svg>
  );
}
