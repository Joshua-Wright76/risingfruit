export function BitterOrange() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="15" fill="#FF8C00" stroke="#FF4500" strokeWidth="2"/>
      <rect x="30" y="17" width="4" height="5" fill="#228B22" rx="1"/>
      <ellipse cx="32" cy="17" rx="4" ry="2" fill="#7CB342"/>
      <path d="M 24 30 Q 28 28 32 30 Q 36 28 40 30" stroke="#CD853F" strokeWidth="2" fill="none" opacity="0.7"/>
      <circle cx="32" cy="34" r="2" fill="#FFE4B5" opacity="0.8"/>
      <line x1="32" y1="34" x2="32" y2="22" stroke="#FFE4B5" strokeWidth="1" opacity="0.4"/>
      <line x1="32" y1="34" x2="45" y2="34" stroke="#FFE4B5" strokeWidth="1" opacity="0.4"/>
    </svg>
  );
}
