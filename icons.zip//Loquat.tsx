export function Loquat() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="32" cy="36" rx="12" ry="14" fill="#FFA500" stroke="#D2691E" strokeWidth="2"/>
      <path d="M 32 22 Q 28 18 26 14" stroke="#228B22" strokeWidth="2" fill="none"/>
      <ellipse cx="38" cy="12" rx="8" ry="4" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <ellipse cx="26" cy="14" rx="6" ry="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <line x1="32" y1="36" x2="32" y2="42" stroke="#8B4513" strokeWidth="1.5" opacity="0.3"/>
    </svg>
  );
}
