export function Avocado() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 32 18 Q 22 22 20 34 Q 20 46 32 50 Q 44 46 44 34 Q 42 22 32 18 Z" fill="#6B8E23" stroke="#556B2F" strokeWidth="2"/>
      <circle cx="32" cy="36" r="6" fill="#8B4513" stroke="#654321" strokeWidth="2"/>
      <circle cx="32" cy="36" r="3" fill="#D2B48C"/>
    </svg>
  );
}
