export function CommonGuava() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="14" fill="#F0E68C" stroke="#BDB76B" strokeWidth="2"/>
      <path d="M 32 20 Q 36 16 40 18" stroke="#556B2F" strokeWidth="2" fill="none"/>
      <ellipse cx="38" cy="18" rx="6" ry="3" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <circle cx="32" cy="34" r="8" fill="#FFB6C1" opacity="0.5"/>
      <circle cx="30" cy="32" r="1.5" fill="#8B4513"/>
      <circle cx="34" cy="32" r="1.5" fill="#8B4513"/>
      <circle cx="28" cy="36" r="1.5" fill="#8B4513"/>
      <circle cx="36" cy="36" r="1.5" fill="#8B4513"/>
      <circle cx="32" cy="38" r="1.5" fill="#8B4513"/>
      <circle cx="30" cy="29" r="1" fill="#8B4513"/>
      <circle cx="34" cy="29" r="1" fill="#8B4513"/>
    </svg>
  );
}
