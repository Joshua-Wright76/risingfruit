export function Grape() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="42" r="5" fill="#8B008B" stroke="#4B0082" strokeWidth="1.5"/>
      <circle cx="26" cy="36" r="5" fill="#8B008B" stroke="#4B0082" strokeWidth="1.5"/>
      <circle cx="38" cy="36" r="5" fill="#8B008B" stroke="#4B0082" strokeWidth="1.5"/>
      <circle cx="32" cy="30" r="5" fill="#9370DB" stroke="#4B0082" strokeWidth="1.5"/>
      <circle cx="26" cy="24" r="4.5" fill="#9370DB" stroke="#4B0082" strokeWidth="1.5"/>
      <circle cx="38" cy="24" r="4.5" fill="#9370DB" stroke="#4B0082" strokeWidth="1.5"/>
      <path d="M 32 20 Q 34 16 36 14 L 40 12 Q 42 12 42 14 L 40 16 Q 38 16 36 14" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
    </svg>
  );
}
