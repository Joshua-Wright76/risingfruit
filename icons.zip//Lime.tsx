export function Lime() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="14" fill="#32CD32" stroke="#228B22" strokeWidth="2"/>
      <path d="M 32 20 Q 34 16 38 16" stroke="#228B22" strokeWidth="2" fill="none"/>
      <ellipse cx="38" cy="16" rx="5" ry="2.5" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <circle cx="32" cy="34" r="2" fill="#90EE90" opacity="0.8"/>
      <line x1="32" y1="34" x2="32" y2="22" stroke="#90EE90" strokeWidth="1" opacity="0.5"/>
      <line x1="32" y1="34" x2="44" y2="34" stroke="#90EE90" strokeWidth="1" opacity="0.5"/>
      <line x1="32" y1="34" x2="22" y2="44" stroke="#90EE90" strokeWidth="1" opacity="0.5"/>
      <line x1="32" y1="34" x2="42" y2="44" stroke="#90EE90" strokeWidth="1" opacity="0.5"/>
    </svg>
  );
}
