export function Apple() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="36" r="15" fill="#DC143C" stroke="#8B0000" strokeWidth="2"/>
      <path d="M 28 22 Q 28 20 30 19" fill="none" stroke="#8B0000" strokeWidth="1.5"/>
      <rect x="30" y="16" width="2.5" height="6" fill="#8B4513" rx="1"/>
      <path d="M 32 16 Q 36 14 40 16 Q 42 18 40 20 Q 38 20 36 18" fill="#7CB342" stroke="#558B2F" strokeWidth="1.5"/>
      <ellipse cx="26" cy="32" rx="4" ry="6" fill="#FF6B6B" opacity="0.4"/>
    </svg>
  );
}
