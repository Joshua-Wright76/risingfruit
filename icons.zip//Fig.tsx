export function Fig() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 32 22 Q 24 24 22 32 Q 22 42 28 48 Q 32 50 36 48 Q 42 42 42 32 Q 40 24 32 22 Z" fill="#6F4E37" stroke="#5D4037" strokeWidth="2"/>
      <circle cx="32" cy="24" r="2.5" fill="#8B7355"/>
      <path d="M 29 26 L 31 22 L 33 22 L 35 26" stroke="#556B2F" strokeWidth="1.5" fill="none"/>
      <circle cx="28" cy="34" r="1.5" fill="#CD853F" opacity="0.7"/>
      <circle cx="36" cy="36" r="1.5" fill="#CD853F" opacity="0.7"/>
      <circle cx="32" cy="40" r="1.5" fill="#CD853F" opacity="0.7"/>
      <circle cx="30" cy="44" r="1.5" fill="#CD853F" opacity="0.7"/>
    </svg>
  );
}
