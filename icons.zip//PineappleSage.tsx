export function PineappleSage() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="32" y1="48" x2="32" y2="18" stroke="#6B8E23" strokeWidth="2"/>
      <ellipse cx="28" cy="24" rx="8" ry="5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <ellipse cx="36" cy="28" rx="7" ry="4.5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <ellipse cx="28" cy="34" rx="8" ry="5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <ellipse cx="36" cy="38" rx="7" ry="4.5" fill="#9ACD32" stroke="#6B8E23" strokeWidth="1.5"/>
      <circle cx="40" cy="22" r="3" fill="#FF6B6B" stroke="#DC143C" strokeWidth="1.5"/>
      <circle cx="24" cy="30" r="2.5" fill="#FF6B6B" stroke="#DC143C" strokeWidth="1.5"/>
      <circle cx="40" cy="34" r="2.5" fill="#FF6B6B" stroke="#DC143C" strokeWidth="1.5"/>
    </svg>
  );
}
