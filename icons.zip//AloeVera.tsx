export function AloeVera() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Center leaf */}
      <path d="M 32 48 L 30 40 Q 28 24 32 16 Q 36 24 34 40 L 32 48 Z" fill="#7CB342" stroke="#558B2F" strokeWidth="2"/>
      
      {/* Left leaf */}
      <path d="M 28 46 L 26 38 Q 22 28 20 22 Q 24 26 28 34 L 28 46 Z" fill="#8FBC8F" stroke="#558B2F" strokeWidth="2"/>
      
      {/* Right leaf */}
      <path d="M 36 46 L 38 34 Q 40 26 44 22 Q 42 28 38 38 L 36 46 Z" fill="#8FBC8F" stroke="#558B2F" strokeWidth="2"/>
      
      {/* Spikes on center leaf */}
      <line x1="30" y1="22" x2="28" y2="20" stroke="#558B2F" strokeWidth="1"/>
      <line x1="34" y1="22" x2="36" y2="20" stroke="#558B2F" strokeWidth="1"/>
      <line x1="30" y1="30" x2="28" y2="28" stroke="#558B2F" strokeWidth="1"/>
      <line x1="34" y1="30" x2="36" y2="28" stroke="#558B2F" strokeWidth="1"/>
      <line x1="30" y1="38" x2="28" y2="36" stroke="#558B2F" strokeWidth="1"/>
      <line x1="34" y1="38" x2="36" y2="36" stroke="#558B2F" strokeWidth="1"/>
    </svg>
  );
}
