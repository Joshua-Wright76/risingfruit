export function Banana() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Bunch of 3 bananas */}
      {/* Left banana */}
      <path d="M 28 20 Q 22 24 20 32 Q 19 40 22 46 Q 24 46 26 44 Q 28 36 28 28 Q 28 24 28 20 Z" fill="#FFD700" stroke="#FFA500" strokeWidth="2"/>
      
      {/* Center banana */}
      <path d="M 32 18 Q 28 22 26 30 Q 25 38 28 46 Q 30 46 32 44 Q 34 36 34 26 Q 34 22 32 18 Z" fill="#FFED4E" stroke="#FFA500" strokeWidth="2"/>
      
      {/* Right banana */}
      <path d="M 36 20 Q 34 24 34 32 Q 34 40 38 46 Q 40 46 42 44 Q 44 36 42 28 Q 40 24 36 20 Z" fill="#FFD700" stroke="#FFA500" strokeWidth="2"/>
      
      {/* Stem at top */}
      <ellipse cx="32" cy="18" rx="6" ry="3" fill="#8B7355" stroke="#654321" strokeWidth="1.5"/>
      
      {/* Darker edges on bananas */}
      <line x1="28" y1="24" x2="26" y2="42" stroke="#FFA500" strokeWidth="1" opacity="0.5"/>
      <line x1="32" y1="22" x2="30" y2="44" stroke="#FFA500" strokeWidth="1" opacity="0.5"/>
      <line x1="38" y1="24" x2="40" y2="42" stroke="#FFA500" strokeWidth="1" opacity="0.5"/>
    </svg>
  );
}