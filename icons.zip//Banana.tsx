export function Banana() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 20 20 Q 16 26 16 34 Q 16 42 20 48 Q 24 48 28 46 Q 28 38 28 30 Q 28 22 24 20 Z" fill="#FFD700" stroke="#FFA500" strokeWidth="2"/>
      <line x1="20" y1="20" x2="20" y2="18" stroke="#8B4513" strokeWidth="2"/>
      <ellipse cx="20" cy="18" rx="3" ry="1.5" fill="#654321"/>
    </svg>
  );
}
