export function Kale() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 32 46 Q 26 40 24 32 Q 24 24 28 18 Q 30 20 30 24 Q 30 28 32 32 Z" fill="#2E7D32" stroke="#1B5E20" strokeWidth="2"/>
      <path d="M 32 46 Q 38 40 40 32 Q 40 24 36 18 Q 34 20 34 24 Q 34 28 32 32 Z" fill="#388E3C" stroke="#1B5E20" strokeWidth="2"/>
      <path d="M 20 36 Q 22 30 26 28 Q 28 30 28 34" fill="#4CAF50" stroke="#1B5E20" strokeWidth="1.5"/>
      <path d="M 44 36 Q 42 30 38 28 Q 36 30 36 34" fill="#4CAF50" stroke="#1B5E20" strokeWidth="1.5"/>
      <line x1="32" y1="32" x2="30" y2="28" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="36" x2="30" y2="34" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="32" x2="34" y2="28" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
      <line x1="32" y1="36" x2="34" y2="34" stroke="#66BB6A" strokeWidth="1" opacity="0.6"/>
    </svg>
  );
}
