export function Rosemary() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Left stem */}
      <line x1="26" y1="48" x2="26" y2="16" stroke="#556B2F" strokeWidth="2"/>
      <line x1="26" y1="20" x2="22" y2="18" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="20" x2="30" y2="18" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="26" x2="22" y2="24" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="26" x2="30" y2="24" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="32" x2="22" y2="30" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="32" x2="30" y2="30" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="38" x2="22" y2="36" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="38" x2="30" y2="36" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="44" x2="22" y2="42" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="26" y1="44" x2="30" y2="42" stroke="#6B8E23" strokeWidth="1.5"/>
      
      {/* Center stem */}
      <line x1="32" y1="48" x2="32" y2="16" stroke="#556B2F" strokeWidth="2"/>
      <line x1="32" y1="20" x2="28" y2="18" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="20" x2="36" y2="18" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="26" x2="28" y2="24" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="26" x2="36" y2="24" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="32" x2="28" y2="30" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="32" x2="36" y2="30" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="38" x2="28" y2="36" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="38" x2="36" y2="36" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="44" x2="28" y2="42" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="32" y1="44" x2="36" y2="42" stroke="#6B8E23" strokeWidth="1.5"/>
      
      {/* Right stem */}
      <line x1="38" y1="48" x2="38" y2="16" stroke="#556B2F" strokeWidth="2"/>
      <line x1="38" y1="20" x2="34" y2="18" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="20" x2="42" y2="18" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="26" x2="34" y2="24" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="26" x2="42" y2="24" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="32" x2="34" y2="30" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="32" x2="42" y2="30" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="38" x2="34" y2="36" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="38" x2="42" y2="36" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="44" x2="34" y2="42" stroke="#6B8E23" strokeWidth="1.5"/>
      <line x1="38" y1="44" x2="42" y2="42" stroke="#6B8E23" strokeWidth="1.5"/>
    </svg>
  );
}