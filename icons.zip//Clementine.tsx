export function Clementine() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="34" r="15" fill="#FF8C00" stroke="#FF6347" strokeWidth="2"/>
      <path d="M 32 19 L 34 16 L 36 19" stroke="#228B22" strokeWidth="2" fill="none"/>
      <circle cx="32" cy="34" r="2" fill="#FFE4B5" opacity="0.8"/>
      <line x1="32" y1="34" x2="32" y2="22" stroke="#FFE4B5" strokeWidth="1" opacity="0.5"/>
      <line x1="32" y1="34" x2="44" y2="34" stroke="#FFE4B5" strokeWidth="1" opacity="0.5"/>
      <line x1="32" y1="34" x2="23" y2="43" stroke="#FFE4B5" strokeWidth="1" opacity="0.5"/>
      <line x1="32" y1="34" x2="41" y2="43" stroke="#FFE4B5" strokeWidth="1" opacity="0.5"/>
    </svg>
  );
}
